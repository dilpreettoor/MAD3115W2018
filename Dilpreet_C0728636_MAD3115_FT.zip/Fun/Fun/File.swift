//
//  File.swift
//  Fun
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 Dilpreet. All rights reserved.
//

import Foundation
import UIKit
class GlobalVariables: UIViewController {
    
    static var bg = "bgimage.jpeg"
    
}
