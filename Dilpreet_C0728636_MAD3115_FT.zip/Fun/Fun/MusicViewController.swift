//
//  ViewController.swift
//  Fun
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 Dilpreet. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {
    
    
    var soundPlayEffect: AVAudioPlayer!
    var updater : CADisplayLink! = nil
    
    @IBOutlet weak var mySlidder: UISlider!
    
    @IBOutlet weak var lblMusic: UILabel!
    @IBAction func btnPlay(_ sender: UIButton) {
        
        
        
        
        let path = Bundle.main.path(forResource: "music", ofType:"mp3")
        let url = URL(fileURLWithPath: path!)
        
       
        do {
            soundPlayEffect = try AVAudioPlayer(contentsOf: url)
            soundPlayEffect.prepareToPlay()
            updater = CADisplayLink(target: self, selector: #selector(ViewController.trackAudio))
            updater.add(to: RunLoop.current, forMode: RunLoopMode.commonModes)
            lblMusic.text = "\(soundPlayEffect.currentTime)"
            
            soundPlayEffect.play()
            
        } catch {
            NSLog("Error Loading Audio File")
        }
        
        
        
    }
    
    @IBAction func btnPause(_ sender: UIButton) {
        
        //pause the time
    }
    
    @IBAction func btnStop(_ sender: UIButton) {
       
        if soundPlayEffect != nil {
            soundPlayEffect.stop()
            soundPlayEffect = nil
        }
        lblMusic.text = "00:00:00"
        musicProgress.progress = 0
 
    }
    
    
    @IBAction func volume(_ sender: UISlider) {
        if soundPlayEffect != nil
        {
            soundPlayEffect.volume = sender.value
        }
    }
    
    @IBOutlet weak var musicProgress: UIProgressView!
    
    @objc func trackAudio() {
        if soundPlayEffect != nil
        {
            let normalizedTime = Float(soundPlayEffect.currentTime / soundPlayEffect.duration)
            musicProgress.progress = normalizedTime
            lblMusic.text = stringFromTimeInterval(interval: soundPlayEffect.currentTime)
        }
    }
    
    func stringFromTimeInterval(interval: TimeInterval) -> String {
        
        let ti = NSInteger(interval)
        
        let seconds = ti % 60
        let minutes = (ti / 60) % 60
        let hours = (ti / 3600)
        
        return NSString(format: "%0.2d:%0.2d:%0.2d",hours,minutes,seconds) as String
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "bgimage.jpeg")!)
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

