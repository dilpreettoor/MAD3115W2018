//
//  ImageCollectionViewCell.swift
//  Fun
//
//  Created by MacStudent on 2018-03-12.
//  Copyright © 2018 Dilpreet. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var imageName: UILabel!
    
    
    
    
}
